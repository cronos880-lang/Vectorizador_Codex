"""Contraste de interiores pequeños con la hoja y el material vecinos.

Se conserva la geometría original de cada descarte en el diagnóstico del vector.
Una fotografía no permite distinguir un hueco sombreado arbitrario de una marca
con idéntica forma y reflectancia. El filtro se abstiene si la hoja no aporta
una referencia óptica uniforme o si la geometría sugiere un mecanizado regular.
"""
from __future__ import annotations

import cv2
import numpy as np


def _borde_recuperado(gris, circulo):
    """Obtiene evidencia fotográfica para un círculo añadido por recuperación."""
    cx, cy = circulo['centro_px']
    r = circulo['radio_px']
    margen = int(np.ceil(2*r+2))
    x0, y0 = max(0, int(cx)-margen), max(0, int(cy)-margen)
    roi = gris[y0:int(cy)+margen+1, x0:int(cx)+margen+1]
    ys, xs = np.ogrid[:roi.shape[0], :roi.shape[1]]
    dist = np.hypot(xs+x0-cx, ys+y0-cy)
    centro = roi[dist < .5*r]
    material = roi[(dist > 1.4*r) & (dist < 1.8*r)]
    if centro.size < 3 or material.size < 10:
        return None
    claro, oscuro = np.median(centro), np.median(material)
    if claro-oscuro < 25:
        return None
    # Interpolar antes de extraer el borde atenúa la cuantización en huecos
    # de pocos píxeles. La geometría CAD original no depende de este contorno.
    imagen = cv2.resize(roi.astype(np.float32), None, fx=3, fy=3, interpolation=cv2.INTER_LINEAR)
    mascara = np.uint8(imagen > .5*(claro+oscuro))
    formas, _ = cv2.findContours(mascara, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    for forma in formas:
        pts = (forma.reshape(-1, 2).astype(np.float32)+.5)/3 - .5 + np.float32([x0, y0])
        if cv2.pointPolygonTest(pts, (cx,cy), False) >= 0:
            if .45*np.pi*r*r < cv2.contourArea(pts) < 1.7*np.pi*r*r:
                return pts
    return None


def _geometria_candidata(contorno, area_exterior, gris):
    if contorno.get('tipo') != 'interior' or contorno.get('origen_deteccion') == 'anillo_optico':
        return None
    puntos = np.asarray(contorno.get('borde_px') or contorno['puntos'], np.float32)
    if contorno.get('origen_deteccion') == 'recuperado' and contorno.get('circulo'):
        puntos = _borde_recuperado(gris, contorno['circulo'])
        if puntos is None:
            return None
    area = cv2.contourArea(puntos)
    if not 8 <= area <= .016 * area_exterior:
        return None
    _, (ancho, alto), _ = cv2.minAreaRect(puntos)
    menor, mayor = sorted((ancho, alto))
    perimetro = cv2.arcLength(puntos, True)
    if menor < 3 or mayor > 2.2 * menor or perimetro <= 0:
        return None
    # Un círculo, rectángulo o ranura puede verse oscuro por la pared de la pieza.
    if area / (ancho * alto) >= .85 or 4 * np.pi * area / perimetro**2 >= .85:
        return None
    # La etiqueta CIRCLE de la primera pasada es solo una hipótesis.
    # Contrastar el borde observado con una elipse protege agujeros y avellanados
    # vistos en perspectiva aunque el ajuste de círculo inicial haya fallado.
    if len(puntos) >= 5:
        centro, ejes, giro = cv2.fitEllipse(puntos)
        if min(ejes) > 0:
            a = np.deg2rad(giro)
            rotacion = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
            locales = (puntos-centro) @ rotacion
            radios = np.linalg.norm(locales / (.5*np.asarray(ejes)), axis=1)
            if np.percentile(np.abs(radios-1), 85) < .095:
                return None
    return puntos


def _muestras_hoja(gris, exterior):
    """Banda exterior de la pieza, muestreada sobre una máscara acotada."""
    x, y, w, h = cv2.boundingRect(exterior)
    margen = max(8, round(min(w, h) * .055))
    x0, y0 = max(0, x-margen), max(0, y-margen)
    region = gris[y0:y+h+margen, x0:x+w+margen]
    escala = min(1., 700 / max(region.shape))
    tam = tuple(max(1, round(n*escala)) for n in region.shape[::-1])
    mascara = np.zeros(tam[::-1], np.uint8)
    pts = np.rint((exterior - [x0, y0]) * escala).astype(np.int32)
    cv2.fillPoly(mascara, [pts], 255)
    dist = cv2.distanceTransform(255-mascara, cv2.DIST_L2, 3)
    ys, xs = np.where((dist >= max(2, margen*.4*escala)) & (dist < margen*escala))
    if len(xs) < 24:
        return None
    paso = max(1, len(xs)//2048)
    xs = np.clip(x0 + np.rint(xs[::paso]/escala).astype(int), 0, gris.shape[1]-1)
    ys = np.clip(y0 + np.rint(ys[::paso]/escala).astype(int), 0, gris.shape[0]-1)
    return xs, ys, gris[ys, xs]


def _contraste(gris, puntos, hoja):
    x, y, w, h = cv2.boundingRect(puntos)
    margen = max(4, min(24, max(w, h)//2))
    x0, y0 = max(0, x-margen), max(0, y-margen)
    roi = gris[y0:y+h+margen, x0:x+w+margen]
    mascara = np.zeros(roi.shape, np.uint8)
    cv2.fillPoly(mascara, [np.rint(puntos - [x0, y0]).astype(np.int32)], 255)
    nucleo = cv2.erode(mascara, np.ones((3, 3), np.uint8))
    interior = roi[nucleo != 0]
    material = roi[mascara == 0]
    if len(interior) < 5 or len(material) < 20:
        return None
    xs, ys, valores = hoja
    distancia = (xs-(x+w/2))**2 + (ys-(y+h/2))**2
    limite = np.percentile(distancia, 18)
    vecinos = valores[distancia <= limite]
    bajo, papel, alto = np.percentile(vecinos, [10, 50, 90])
    oscuro, claro = np.percentile(material, [45, 85])
    brillo = np.percentile(interior, 85)
    rango = papel - oscuro
    # Abstenerse ante sombras fuertes, reglas o gradientes sobre el papel.
    if rango < 37 or alto-bajo > .22*rango:
        return None
    diferencia = bajo - brillo
    if diferencia < max(18., .13*rango, 2*(alto-bajo)):
        return None
    return {
        'diferencia_hoja': round(float(diferencia), 2),
        'fraccion_contraste': round(float((brillo-oscuro)/rango), 3),
        'variacion_material': round(float((claro-oscuro)/rango), 3),
        'area_observada_px2': round(cv2.contourArea(puntos), 2),
    }


def filtrar_textura(imagen_bgr, vector):
    """Contrasta los polígonos interiores con el papel. Devuelve un vector nuevo."""
    contornos = vector['contornos']
    exteriores = [c for c in contornos if c.get('tipo') == 'exterior']
    if len(exteriores) != 1:
        return vector
    ext = exteriores[0]
    exterior = np.asarray(ext.get('borde_px') or ext['puntos'], np.float32)
    area = cv2.contourArea(exterior)
    gris = cv2.cvtColor(imagen_bgr, cv2.COLOR_BGR2GRAY)
    candidatos = []
    for i, contorno in enumerate(contornos):
        puntos = _geometria_candidata(contorno, area, gris)
        if puntos is not None:
            candidatos.append((i, puntos))
    if not candidatos:
        return vector
    hoja = _muestras_hoja(gris, exterior)
    if hoja is None:
        return vector
    evidencia = {}
    for i, puntos in candidatos:
        valores = _contraste(gris, puntos, hoja)
        if valores is not None:
            evidencia[i] = valores
    # Para material uniforme, exigir al menos otra marca de tamaño
    # semejante y también incompatible con el fondo. Un único detalle oscuro ambiguo se conserva para el editor.
    areas = np.sort([v['area_observada_px2'] for v in evidencia.values()])
    descartados = {}
    for i, valores in evidencia.items():
        area_marca = valores['area_observada_px2']
        repeticiones = areas.searchsorted(2*area_marca, side='right') - areas.searchsorted(area_marca/2)
        if repeticiones >= 2 or valores['variacion_material'] > .16:
            descartados[i] = {
                'contorno': contornos[i],
                'motivo': 'Interior pequeño e irregular con brillo ajeno a la hoja y compatible con textura',
                **valores,
            }
    if not descartados:
        return vector
    return {**vector, 'contornos': [c for i, c in enumerate(contornos) if i not in descartados],
            'contornos_textura_descartados': [*vector.get('contornos_textura_descartados', []),
                                               *descartados.values()]}
