"""Extracción de la geometría editable y de su silueta desde la misma foto."""
from motor.agujeros_adicionales import recuperar_agujeros
from motor.anillos_opticos import reconstruir_anillos
from motor.funciones_avanzadas import evaluar_bordes
from motor.textura_optica import filtrar_textura
from motor.vectorizar import dibujar_silueta, extraer_contornos


def vectorizar_pieza(imagen, umbral=120, recorte=None, exclusiones=None, recuperar=True):
    vector = extraer_contornos(imagen, umbral, 'precision', recorte, exclusiones,
                               generar_silueta=False)
    if recuperar:
        vector = recuperar_agujeros(imagen, vector)
    vector = reconstruir_anillos(imagen, vector)
    vector = filtrar_textura(imagen, vector)
    vector = evaluar_bordes(imagen, vector)
    contornos = vector['contornos']
    vector['agujeros_recuperados'] = sum(c.get('origen_deteccion') == 'recuperado' for c in contornos)
    vector['silueta_png'] = dibujar_silueta(contornos, *imagen.shape[:2])
    return vector
