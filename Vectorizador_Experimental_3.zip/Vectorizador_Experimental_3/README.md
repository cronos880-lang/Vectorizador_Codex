# Vectorizador V2.6 Experimental 3

Las instrucciones de Windows están en LEEME_PRIMERO.txt y los resultados en INFORME.md.
