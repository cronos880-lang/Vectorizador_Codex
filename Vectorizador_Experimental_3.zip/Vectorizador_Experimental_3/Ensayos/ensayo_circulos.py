import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
import cv2, numpy as np
from motor.vectorizar import extraer_contornos
from motor.editor_cad import documento_inicial
from motor.agujeros_adicionales import recuperar_agujeros
results=[]
for scale in (2.5,3.34,5.,8.):
    for diameter in (4.7,8.,11.):
        for shift in (.0,.35,.7):
            y,x=np.mgrid[:180,:240]
            radius=scale*diameter/2
            image=np.full(x.shape,224,np.float32)
            image[15:160,20:210]=45
            # Approximate pixel coverage with an 8 x 8 sampling grid.
            coverage=sum(((x+dx-116-shift)**2+(y+dy-85-shift)**2<radius**2).astype(float)
                         for dx in (np.arange(8)+.5)/8-.5 for dy in (np.arange(8)+.5)/8-.5)/64
            image+=coverage*179
            image=cv2.cvtColor(cv2.GaussianBlur(image,(5,5),.8).astype('uint8'),cv2.COLOR_GRAY2BGR)
            v=recuperar_agujeros(image,extraer_contornos(image))
            doc=documento_inicial(v,scale,scale)
            holes=[e for e in doc['entidades'] if e['capa']=='AGUJEROS']
            measured=2*holes[0]['radio'] if len(holes)==1 and holes[0]['tipo']=='circle' else None
            results.append([scale,diameter,shift,measured])
err=[abs(row[3]-row[1]) for row in results if row[3] is not None]
print('casos',len(results),'reconocidos',len(err),'error medio, p95, máximo', np.mean(err), np.percentile(err,95),max(err))
Path(sys.argv[2]).write_text(json.dumps(results))
