"""Banco óptico independiente. Uso: python ensayo_materiales_e2.py APP RESULTADO_JSON [--imagenes DIR].

Las imágenes son sintéticas. La escala real del dibujo, especificada al abrir el
editor, aísla la detección de foto de la calibración de la plantilla. Las cotas
esperadas se calculan antes de crear las imágenes. Un aro tiene como objetivo
su contorno exterior, y un agujero pasante el borde del material.
"""
import argparse
import io
import json
import math
import sys
from pathlib import Path

import cv2
import ezdxf
import numpy as np
from ezdxf.path import make_path
from shapely import affinity
from shapely.geometry import LineString, Point, Polygon, box


def disco(x, y, r):
    return Point(x, y).buffer(r, quad_segs=96)


def escena(familia, escala, giro, semilla, reserva=False):
    if familia == 'tejido':
        perfil = Polygon([(21, 18), (31, 20), (85, 33), (87, 39), (55, 46),
                          (34, 57), (22, 62), (20, 58), (23, 48), (23, 27)]).buffer(2)
        rasgos = [('aro', disco(26, 22, 2.45)), ('aro', disco(25.3, 57.5, 2.45)),
                  ('aro', disco(40, 26, 2.9)), ('aro', disco(39.5, 47, 2.9)),
                  ('pasante', disco(81.8, 36.2, 3.25))]
        marcas = [(54, 39), (62, 34), (69, 36)]
    elif familia == 'chapa':
        perfil = box(22, 18, 76, 57).buffer(4)
        rasgos = [('aro', disco(31, 28, 3.4)), ('aro', disco(68, 48, 3.2)),
                  ('pasante', disco(52, 41, 2.8)),
                  ('ranura', LineString([(32, 43), (39, 49)]).buffer(1.65))]
        marcas = [(43, 29), (60, 32)]
    else:
        perfil = disco(51, 39, 27)
        rasgos = [('pasante', disco(37, 33, 2.45)),
                  ('sombra', disco(56, 23, 2.4)),
                  ('ranura', LineString([(49, 42), (59, 42)]).buffer(1.9)),
                  ('irregular', Polygon([(44, 50), (48, 50), (45.5, 54)]))]
        marcas = [(61, 50), (33, 43)]
    if reserva:
        # Escenas adicionales definidas tras finalizar el ajuste del banco inicial.
        if familia == 'disco':
            perfil = affinity.scale(disco(51,39,28), xfact=1.23, yfact=.92)
            rasgos += [('pasante', disco(67,37,1.75))]
        elif familia == 'chapa':
            perfil = Polygon([(18,18),(71,15),(79,25),(80,57),(35,61),(18,52)]).buffer(2)
            rasgos += [('pasante', disco(38,25,2.2))]
        else:
            perfil = perfil.union(disco(33.5,20.5,5))
            rasgos += [('pasante', disco(33.5,20.5,1.8))]
    centro = (52., 40.)
    def rotar(g):
        return affinity.rotate(g, giro, origin=centro)
    perfil = rotar(perfil)
    rasgos = [(tipo, rotar(g)) for tipo, g in rasgos]
    ss = 3
    h, w = round(84*escala), round(108*escala)
    y, x = np.indices((h*ss, w*ss), dtype=np.float32)
    xx = (x+.5)/(escala*ss)
    yy = (y+.5)/(escala*ss)
    rng = np.random.default_rng(semilla)
    papel = 218 + .16*xx - .09*yy + 1.9*np.cos(yy/13)
    grano = rng.normal(0, 1.1, papel.shape).astype(np.float32)
    papel = np.dstack([papel+grano, papel+grano+1, papel+grano-1])
    im = papel.copy()

    def mask(g):
        m = np.zeros(y.shape, np.uint8)
        coords = np.asarray(g.exterior.coords)
        cv2.fillPoly(m, [np.rint(coords*escala*ss-.5).astype(np.int32)], 1)
        return m.astype(bool)
    nm = mask(perfil)
    tejido = (np.sin(3.7*xx + 2.4*yy) + .7*np.sin(2*xx-4*yy))
    base = {'tejido': 49, 'chapa': 73, 'disco': 61}[familia] + (12 if familia=='tejido' else 2.5)*tejido + grano
    material = np.dstack([base+3, base+1, base])
    im[nm] = material[nm]
    for j,(cx, cy) in enumerate(marcas):
        coords=np.array([[0,0],[1.25,-.4],[1.6,-1.3],[2.55,-.9],[2.65,1.2],
                         [.65,1.45],[-.5,.85]])
        g=rotar(Polygon(coords+[cx,cy])); m=mask(g)
        brillo = (154, 182, 141)[j%3]
        im[m]=(brillo+3,brillo,brillo-2)
    for j,(tipo,g) in enumerate(rasgos):
        m = mask(g)
        if tipo=='aro':
            cx,cy=g.centroid.coords[0]; r=(g.bounds[2]-g.bounds[0])/2
            rho=np.hypot(xx-cx, yy-cy)/r
            theta=np.arctan2(yy-cy,xx-cx)
            fase=j*1.27+giro/63
            # Aro metálico opaco, con núcleo oscuro y una zona en sombra sobre
            # la corona. El contorno exterior sigue siendo un único círculo.
            nivel=175+49*np.cos(theta-fase)-31*np.cos(2*theta+fase)
            metal=np.dstack([nivel-53, nivel+7, nivel+30]) if familia=='tejido' else np.dstack([nivel+12,nivel+9,nivel+7])
            im[m]=metal[m]
            rim=m & (rho>.91)
            im[rim]=metal[rim]*.83
            nucleo=m & (rho < (.52 if j%2==0 else .48))
            im[nucleo]=[43,56,65]
            centro_luz=nucleo & (np.hypot(xx-cx-.14*r, yy-cy+.12*r)<.24*r)
            im[centro_luz]=[110,128,133]
        elif tipo=='sombra':
            im[m]=papel[m]*.77
        else:
            im[m]=papel[m]
    if reserva:
        # Sombra muy suave desde un lateral y balance de blancos cálido.
        luz=.88+.13*(xx/108)+.018*np.sin(yy*.09)
        im=im * luz[:,:,None] * np.array([.91,1.,1.035])[None,None,:]
    image=cv2.resize(np.uint8(np.clip(im,0,255)),(w,h),interpolation=cv2.INTER_AREA)
    image=cv2.GaussianBlur(image,(3,3),.57)
    ok, jpg=cv2.imencode('.jpg',image,[cv2.IMWRITE_JPEG_QUALITY,91])
    assert ok
    return jpg.tobytes(), [(tipo,affinity.translate(g,xoff=-.5/escala,yoff=-.5/escala)) for tipo,g in rasgos]


def comparar(dxf, vector, escala, objetivos):
    # La exportación reubica el origen en la caja del vector y orienta Y hacia arriba.
    samples=np.vstack([np.asarray(c['puntos']) for c in vector['contornos']])
    x0,y1=samples[:,0].min()/escala,samples[:,1].max()/escala
    entidades=[]
    for e in dxf.modelspace():
        if e.dxf.layer!='AGUJEROS':continue
        if e.dxftype()=='CIRCLE':
            x,y=e.dxf.center.x,e.dxf.center.y
            pol=disco(x0+x,y1-y,e.dxf.radius)
        else:
            pol=Polygon([(x0+p.x,y1-p.y) for p in make_path(e).flattening(.012)])
        entidades.append((e.dxftype(),pol))
    # Por localización uno a uno, con solapamiento mínimo. Los polígonos
    # fragmentados o demasiado pequeños no equivalen a la abertura completa.
    parejas=[]
    for i,(_,obj) in enumerate(objetivos):
        for j,(_,pol) in enumerate(entidades):
            if not pol.is_valid:continue
            inter=obj.intersection(pol).area
            iou=inter/(obj.area+pol.area-inter)
            if iou >= .50:parejas.append((iou,i,j))
    usados,asignados=set(),{}
    for iou,i,j in sorted(parejas,reverse=True):
        if i not in asignados and j not in usados:
            asignados[i]=(iou,j); usados.add(j)
    detalle=[]
    for i,(tipo,obj) in enumerate(objetivos):
        registro={'objetivo':tipo}
        if i in asignados:
            iou,j=asignados[i]; prim,pol=entidades[j]
            registro.update(primitiva=prim,IoU=round(iou,3),error_centro_mm=round(obj.centroid.distance(pol.centroid),4))
            if tipo in ('pasante','sombra','aro') and prim=='CIRCLE':
                registro['error_diametro_mm']=round(pol.bounds[2]-pol.bounds[0]-(obj.bounds[2]-obj.bounds[0]),4)
        detalle.append(registro)
    return {'esperados':len(objetivos),'detectados':len(entidades),'aciertos':len(asignados),
            'falsos_positivos':len(entidades)-len(usados),'omitidos':len(objetivos)-len(asignados),
            'detalle':detalle}


def overlay_dxf(raw, doc, vector, escala):
    """Superposición calculada desde las entidades del archivo reabierto."""
    photo = cv2.imdecode(np.frombuffer(raw,np.uint8), cv2.IMREAD_COLOR)
    all_points = np.vstack([c['puntos'] for c in vector['contornos']])
    x0,y1=all_points[:,0].min(),all_points[:,1].max()
    for ent in doc.modelspace():
        points = np.array([(x0+p.x*escala, y1-p.y*escala) for p in make_path(ent).flattening(.008)])
        color = (138,243,86) if ent.dxf.layer=='CONTORNO_EXTERIOR' else (10,156,255)
        cv2.polylines(photo,[np.rint(16*points).astype(np.int32)],True,color,1,cv2.LINE_AA,4)
    return photo


def main():
    from fastapi.testclient import TestClient
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('app',type=Path)
    parser.add_argument('salida',type=Path)
    parser.add_argument('--imagenes',type=Path)
    parser.add_argument('--reserva',action='store_true',help='Escenas adicionales fuera del ajuste inicial')
    parser.add_argument('--superponer',type=Path,help='Carpeta para superponer los DXF leídos sobre los JPEG sintéticos')
    args=parser.parse_args()
    sys.path.insert(0,str(args.app.resolve()))
    from servidor import app
    cliente=TestClient(app)
    resultados=[]
    if args.imagenes: args.imagenes.mkdir(parents=True,exist_ok=True)
    if args.superponer: args.superponer.mkdir(parents=True,exist_ok=True)
    casos=[('tejido',3.4,0),('tejido',4.6,17),('chapa',3.5,-16),('chapa',4.4,11),
           ('disco',3.8,25),('disco',5.,-28)]
    if args.reserva:
        casos=[('tejido',3.7,-23),('tejido',4.75,31),('chapa',3.2,19),
               ('chapa',4.2,-27),('disco',3.6,-10),('disco',4.8,37)]
    for idx,(familia,escala,giro) in enumerate(casos):
        raw,objetivos=escena(familia,escala,giro,(781 if args.reserva else 431)+idx,args.reserva)
        nombre=('reserva_' if args.reserva else '')+f'{familia}_{idx+1}'
        if args.imagenes:(args.imagenes/(nombre+'.jpg')).write_bytes(raw)
        r=cliente.post('/api/vectorizar',files={'archivo':(nombre+'.jpg',raw,'image/jpeg')})
        r.raise_for_status(); v=r.json()
        q=dict(vector=v,px_mm_x=escala,px_mm_y=escala,guardar_copia=False)
        ed=cliente.post('/api/editor/iniciar',json=q)
        if ed.is_success:
            q.update(entidades_editadas=ed.json()['entidades'],exigir_edicion=True)
        res=cliente.post('/api/exportar',json=q);res.raise_for_status()
        dxf=ezdxf.read(io.StringIO(res.text))
        if args.superponer:
            cv2.imwrite(str(args.superponer/(nombre+'.png')),overlay_dxf(raw,dxf,v,escala))
        fila={'exteriores':sum(e.dxf.layer=='CONTORNO_EXTERIOR' for e in dxf.modelspace()),'caso':nombre,'escala':escala,'giro':giro,'editor_http':ed.status_code,**comparar(dxf,v,escala,objetivos)}
        resultados.append(fila)
        print(nombre,{k:fila[k] for k in ('esperados','detectados','aciertos','falsos_positivos','omitidos')})
    args.salida.write_text(json.dumps(resultados,indent=2,ensure_ascii=False))

if __name__=='__main__': main()
