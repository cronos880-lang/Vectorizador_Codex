import sys,time,resource,json
from pathlib import Path
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
import cv2,numpy as np
from fastapi.testclient import TestClient
from servidor import app
c=TestClient(app)
im=cv2.imread(str(next((Path(sys.argv[1])/'ejemplos').glob('*V2_1*.png'))))
h,w=im.shape[:2]
src=np.float32([[0,0],[w,0],[w,h],[0,h]])
dst=np.float32([[.04*w,.07*h],[.97*w,0],[.99*w,.99*h],[0,.93*h]])
variants={'original':im,'resolucion65':cv2.resize(im,None,fx=.65,fy=.65,interpolation=cv2.INTER_AREA),'perspectiva':cv2.warpPerspective(im,cv2.getPerspectiveTransform(src,dst),(w,h),borderValue=(185,185,185)),'luz':(im*np.linspace(.68,1.,w)[None,:,None]).astype('uint8')}
out=[]
for name,image in variants.items():
    times=[]
    raw=cv2.imencode('.png',image)[1].tobytes()
    for _ in range(4):
        t=time.perf_counter()
        r=c.post('/api/vectorizar',files={'archivo':('prueba.png',raw,'image/png')}); r.raise_for_status()
        times.append(time.perf_counter()-t)
    v=r.json();cal=v['calibracion']
    q=dict(vector=v,px_mm_x=cal['px_mm_x'],px_mm_y=cal['px_mm_y'],proyectiva=cal.get('proyectiva_automatica'),guardar_copia=False)
    d=c.post('/api/editor/iniciar',json=q);d.raise_for_status()
    doc=d.json();out.append(dict(caso=name,calibracion=cal['estado'],contornos=len(v['contornos']),diametros=[round(2*e['radio'],4) for e in doc['entidades'] if e['tipo']=='circle'],dimensiones=doc['resumen']['dimensiones_mm'],segundos_mediana=float(np.median(times[1:])),RSS_max_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024))
print(json.dumps(out,indent=2))
