from pathlib import Path
import json,os,subprocess,time,urllib.request,sys,tempfile,shutil,socket
from playwright.sync_api import sync_playwright
repos=list(map(Path,sys.argv[1:3]))
photo=next((repos[0]/'ejemplos').glob('*V2_1*.png')).resolve()
with tempfile.TemporaryDirectory() as tmp, sync_playwright() as pw:
    root=Path(tmp)
    browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    for i,repo in enumerate(repos):
        copy=root/str(i)
        shutil.copytree(repo,copy,ignore=shutil.ignore_patterns('.git','Archivos','__pycache__'))
        sock=socket.socket();sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1];sock.close()
        url=f'http://127.0.0.1:{port}'
        proc=subprocess.Popen([sys.executable,'-m','uvicorn','servidor:app','--port',str(port)],cwd=copy,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:
            for _ in range(100):
                try: urllib.request.urlopen(url+'/api/version',timeout=.3).close();break
                except OSError: time.sleep(.1)
            page=browser.new_page()
            page.add_init_script("window.showSaveFilePicker=undefined")
            page.goto(url)
            if i==0:
                page.locator('#fileInput').set_input_files(photo)
                page.locator('#convertBtn').click()
                page.locator('#cadToggle').click()
            else:
                page.locator('#projectFileInput').set_input_files(root/'legacy.vect')
            page.wait_for_function('cad.initialized && cad.entities.length>0 && !state.busy')
            if i==0:
                page.evaluate("""() => {
                    const circle=cad.entities.find(e=>e.tipo==='circle');
                    const original=circle.cx;
                    for(let j=0;j<10;j++) {
                        cad.selected=circle.id;
                        document.getElementById('cadMoveX').value='0.25';
                        cadAplicarMover();
                    }
                    cadDeshacer(); cadRehacer();
                    if(cad.entities.find(e=>e.id===circle.id).cx!==original+2.5)
                        throw Error('Desajuste CAD tras diez movimientos');
                }""")
            with page.expect_download() as download:
                page.evaluate("document.getElementById('projectSave').click()")
            file=root/('legacy.vect' if not i else 'prueba.vect')
            download.value.save_as(file)
            page.close()
        finally: proc.terminate();proc.wait()
    a,b=[json.loads((root/n).read_text())['datos'] for n in ('legacy.vect','prueba.vect')]
    for k in ('foto','vector','scale','manual','crop','cad'):
        assert a[k]==b[k], k
    assert a['ui']['extrusion']==b['ui']['extrusion']
    print('VECT1 reabierto y guardado en Chromium. Foto, escala, vector, CAD e historial y extrusión iguales.')
