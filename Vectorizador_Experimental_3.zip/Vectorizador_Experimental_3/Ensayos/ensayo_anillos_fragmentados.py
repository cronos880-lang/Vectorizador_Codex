"""Controles ópticos de coronas y de perfiles que deben conservarse."""
from pathlib import Path
import argparse
import json
import sys

import cv2
import numpy as np


def escena(tipo, radio, semilla):
    y, x = np.mgrid[:270, :400]
    dx, dy = x-146.45, y-115.65
    distancia = np.hypot(dx, dy)
    angulo = np.arctan2(dy, dx)
    imagen = np.full(x.shape, 225.0)
    imagen[60:173, 65:213] = 45
    if tipo in ('aro', 'ovalado', 'arco'):
        if tipo == 'ovalado':
            distancia = np.hypot(1.32*dx, .79*dy)
        luz = 152 + 65*np.cos(2*angulo+1.65) + 35*np.cos(angulo)
        if tipo == 'arco':
            luz = np.where(dx < 0, 180, 45)
        imagen = np.where((distancia<radio) & (distancia>.48*radio), luz, imagen)
    elif tipo == 'ranura':
        imagen[(abs(dy)<3.3) & (abs(dx)<radio)] = 191
    elif tipo == 'disco':
        imagen[distancia<radio] = 190
    elif tipo == 'dos':
        imagen[(np.hypot(dx+radio,dy)<radio*.6) | (np.hypot(dx-radio,dy)<radio*.6)] = 170
    rng = np.random.default_rng(semilla)
    imagen = np.clip(imagen+rng.normal(0,2,imagen.shape),0,255).astype('uint8')
    return cv2.cvtColor(cv2.GaussianBlur(imagen,(3,3),.6),cv2.COLOR_GRAY2BGR)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('app',type=Path)
    ap.add_argument('salida',type=Path)
    args = ap.parse_args()
    sys.path.insert(0,str(args.app.resolve()))
    from motor.agujeros_adicionales import recuperar_agujeros
    from motor.vectorizar import extraer_contornos
    from motor.anillos_opticos import reconstruir_anillos
    resultados = []
    for i, tipo in enumerate(('aro','ovalado','arco','ranura','disco','dos')):
        for j, radio in enumerate((6.8,7.8,8.8,11.,16.,24.)):
            imagen = escena(tipo,radio,12*i+j)
            original = recuperar_agujeros(imagen,extraer_contornos(imagen))
            salida = reconstruir_anillos(imagen,original)
            opticos = [c for c in salida['contornos'] if c.get('origen_deteccion')=='anillo_optico']
            corregido = opticos[0]['circulo']['radio_px'] if opticos else None
            if tipo=='aro':
                assert len(opticos)==1 and abs(corregido-radio)<.55,(tipo,radio,corregido)
                assert len(salida['contornos'])==2
            else:
                assert not opticos and salida['contornos']==original['contornos'],(tipo,radio)
            resultados.append(dict(tipo=tipo,radio=radio,antes=len(original['contornos'])-1,
                                   despues=len(salida['contornos'])-1,radio_reconstruido=corregido))
    args.salida.write_text(json.dumps(resultados,ensure_ascii=False,indent=2))
    print(f'{len(resultados)} controles de coronas y perfiles superados.')


if __name__=='__main__':
    main()
