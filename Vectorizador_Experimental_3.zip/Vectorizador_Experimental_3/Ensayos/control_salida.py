import sys,io
from pathlib import Path
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
from fastapi.testclient import TestClient
from servidor import app
import ezdxf,trimesh
c=TestClient(app)
for f in sorted((Path(sys.argv[1])/'ejemplos').glob('*.png')):
    v=c.post('/api/vectorizar',files={'archivo':(f.name,f.read_bytes(),'image/png')}).json()
    cal=v['calibracion']
    print(f.name,list(cal),len(v['contornos']))
    p=dict(vector=v,px_mm_x=cal['px_mm_x'],px_mm_y=cal['px_mm_y'],guardar_copia=False)
    if cal.get('proyectiva_automatica'):p['proyectiva']=cal['proyectiva_automatica']
    r=c.post('/api/exportar',json=p);r.raise_for_status(); doc=ezdxf.read(io.StringIO(r.text))
    s=c.post('/api/exportar-stl',json=dict(p,grosor=2.5));s.raise_for_status()
    m=trimesh.load(io.BytesIO(s.content),file_type='stl')
    print([e.dxftype() for e in doc.modelspace()],len(doc.audit().errors),m.is_watertight,m.extents[2])
