import sys
from pathlib import Path
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
import cv2,numpy as np
from motor.vectorizar import extraer_contornos
from motor.funciones_avanzadas import evaluar_bordes
from motor.agujeros_adicionales import recuperar_agujeros
for brillo in (95,145,190):
    im=np.full((250,350,3),220,np.uint8)
    cv2.rectangle(im,(25,30),(320,210),(48,48,48),-1)
    for x,y,r in [(60,65,8),(60,170,8),(130,75,8),(130,160,8),(285,120,13)]:
        cv2.circle(im,(x,y),r,(220,220,220),-1)
    for x,y in [(175,110),(205,95),(225,130)]:
        cv2.fillPoly(im,[np.array([(x,y),(x+10,y-3),(x+8,y+5),(x+1,y+6)])],(brillo,)*3)
    v=recuperar_agujeros(im,extraer_contornos(im))
    v=evaluar_bordes(im,v)
    print('marcados',sum(bool(c.get('revision_recomendada')) for c in v['contornos']))
    print(brillo,[(c['tipo'],bool(c.get('circulo'))) for c in v['contornos']])
