from pathlib import Path
import sys,io,json,tempfile,subprocess
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
import ezdxf,trimesh

from shapely.geometry import shape
from fastapi.testclient import TestClient
from servidor import app
c=TestClient(app)
def poly(points,layer='CONTORNO_EXTERIOR'):
    return dict(tipo='polyline',vertices=[list(pt) for pt in points],cerrada=True,capa=layer)
def circle(x,y,r,layer):
    return dict(tipo='circle',cx=x,cy=y,radio=r,capa=layer)
outer=poly([(0,0,0),(50,0,0),(50,20,0),(35,20,0),(35,35,0),(0,35,0)])
slot=poly([(8,8,0),(20,8,1),(20,14,0),(8,14,1)],'AGUJEROS')
outer2=dict(tipo='rectangle',a=[64,0],b=[76,12],capa='CONTORNO_EXTERIOR')
cases={'ranura_y_esquina':[outer,slot],'isla_y_varias_piezas':[outer,circle(14,13,7,'AGUJEROS'),circle(14,13,2,'CONTORNO_EXTERIOR'),outer2]}
if len(sys.argv)>2:
    d=ezdxf.readfile(sys.argv[2])
    cases['DXF_del_usuario']=[circle(e.dxf.center.x,e.dxf.center.y,e.dxf.radius,e.dxf.layer) if e.dxftype()=='CIRCLE' else poly(e.get_points('xyb'),e.dxf.layer) for e in d.modelspace()]
for name,entities in cases.items():
    for i,e in enumerate(entities):e['id']=str(i)
    for thickness,offset,width in [(1.,0.,None),(2.5,0.,None),(3.,.25,60.),(2.5,-.2,48.)]:
        p=dict(vector={},entidades_editadas=entities,exigir_edicion=True,grosor=thickness,offset_exterior=offset,objetivo_ancho_mm=width,guardar_copia=False)
        s=c.post('/api/exportar-stl',json=p);assert s.is_success,s.text
        m=trimesh.load(io.BytesIO(s.content),file_type='stl')
        assert m.is_watertight and m.is_winding_consistent and m.is_volume and m.nondegenerate_faces().all()
        assert abs(m.extents[2]-thickness)<1e-6
        assert m.euler_number=={'ranura_y_esquina':0,'isla_y_varias_piezas':4,'DXF_del_usuario':-8}[name]
        d=c.post('/api/exportar-dxf-ajustado',json=dict(p,sha256_stl_esperado=s.headers['X-Vectorizador-STL-SHA256']))
        assert d.is_success,d.text
        doc=ezdxf.read(io.StringIO(d.text));assert doc.units==4 and not doc.audit().errors
        assert len(doc.modelspace())==len(entities)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'pieza.dxf';path.write_bytes(d.content)
            data=json.loads(subprocess.check_output(['ogr2ogr','-f','GeoJSON','/vsistdout/',str(path)]))
            rings=[shape(f['geometry']) for f in data['features']]
            assert len(rings)==len(entities)
            xmin=min(g.bounds[0] for g in rings); xmax=max(g.bounds[2] for g in rings)
            ymin=min(g.bounds[1] for g in rings); ymax=max(g.bounds[3] for g in rings)
            assert abs(xmax-xmin-m.extents[0]) < .1 and abs(ymax-ymin-m.extents[1]) < .1

        print(name,thickness,offset,width,'ok')
if 'laboratorio' in sys.argv[1]:
    p=dict(vector={},entidades_editadas=[dict(outer,id='a'),dict(outer,id='b')],grosor=2.5,guardar_copia=False)
    r=c.post('/api/exportar-stl',json=p);assert r.status_code==422 and 'coincidentes' in r.text
    print('Duplicados rechazados.')
