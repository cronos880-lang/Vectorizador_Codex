from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
import cv2,numpy as np,ezdxf
from ezdxf.path import make_path
from shapely.geometry import LineString
from motor.vectorizar import extraer_contornos
from motor.editor_cad import documento_inicial
from motor.agujeros_adicionales import recuperar_agujeros
d=ezdxf.readfile(sys.argv[2]); outer=next(iter(d.modelspace().query('LWPOLYLINE')))
pts=np.array([(v.x,v.y) for v in make_path(outer).flattening(.005)])
cs=[(e.dxf.center.x,e.dxf.center.y,2*e.dxf.radius) for e in d.modelspace().query('CIRCLE')]
cs=[(x,y,8 if y==max(p[1] for p in cs) else diameter) for x,y,diameter in cs]
gt=LineString(np.vstack((pts,pts[0])))
for scale in (2.5,3.34,5.,8.):
    def pixel(x,y):return [round((x*scale+29.5)*8),round(((70-y)*scale+29.5)*8)]
    im=np.full((int(70*scale+110)*8,int(50*scale+110)*8),224,np.uint8)
    cv2.fillPoly(im,[np.array([pixel(x,y) for x,y in pts])],45)
    for x,y,diam in cs:cv2.circle(im,tuple(pixel(x,y)),round(diam*scale*4),224,-1)
    photo=cv2.cvtColor(cv2.GaussianBlur(cv2.resize(im,None,fx=.125,fy=.125,interpolation=cv2.INTER_AREA),(5,5),.8),cv2.COLOR_GRAY2BGR)
    v=recuperar_agujeros(photo,extraer_contornos(photo))
    ext=next(c for c in v['contornos'] if c['tipo']=='exterior')
    arr=np.array(ext['borde_px']);xy=np.column_stack(((arr[:,0]-29.0625)/scale,70-(arr[:,1]-29.0625)/scale))
    curve=LineString(np.vstack((xy,xy[0])))
    doc=documento_inicial(v,scale,scale)
    print(scale,'contornos',len(v['contornos']),'diametros',sorted(round(e['radio']*2,3) for e in doc['entidades'] if e['tipo']=='circle'),'Hausdorff mm',round(curve.hausdorff_distance(gt),3))
