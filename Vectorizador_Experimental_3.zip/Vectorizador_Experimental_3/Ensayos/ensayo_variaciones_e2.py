"""Validación adicional sobre JPEG con exposición y desenfoque modificados."""
from pathlib import Path
import sys, io, json
import cv2, ezdxf, numpy as np
from fastapi.testclient import TestClient
from ensayo_materiales_e2 import escena, comparar

sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
from servidor import app

cliente = TestClient(app)
salida = []
for i, familia in enumerate(('tejido', 'chapa', 'disco')):
    for brillo, sigma, escala, giro in ((.87,.45,3.8,-12), (1.04,.7,4.2,28),(.95,.6,3.6,8)):
        raw, objetivos = escena(familia, escala, giro, 800+i)
        im = cv2.imdecode(np.frombuffer(raw,np.uint8),cv2.IMREAD_COLOR)
        im = cv2.convertScaleAbs(cv2.GaussianBlur(im,(3,3),sigma),alpha=brillo)
        data=cv2.imencode('.jpg',im,[cv2.IMWRITE_JPEG_QUALITY,87])[1].tobytes()
        r=cliente.post('/api/vectorizar',files={'archivo':('prueba.jpg',data,'image/jpeg')})
        r.raise_for_status()
        v=r.json()
        q=dict(vector=v,px_mm_x=escala,px_mm_y=escala,guardar_copia=False)
        ed=cliente.post('/api/editor/iniciar',json=q)
        if ed.is_success:
            q.update(entidades_editadas=ed.json()['entidades'])
        res=cliente.post('/api/exportar',json=q)
        res.raise_for_status()
        fila=comparar(ezdxf.read(io.StringIO(res.text)),v,escala,objetivos)
        fila.update(familia=familia,escala=escala,giro=giro,editor=ed.status_code)
        salida.append(fila)
Path(sys.argv[2]).write_text(json.dumps(salida,indent=2))
print({k:sum(x[k] for x in salida) for k in ('esperados','omitidos','falsos_positivos')})
