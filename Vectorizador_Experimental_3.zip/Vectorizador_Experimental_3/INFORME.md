# Vectorizador V2.6 Experimental 3

Ante reflejos en el centro del inserto, el motor admite una corona incompleta si al menos el 95 % del borde exterior tiene soporte óptico y el ajuste circular supera las comprobaciones geométricas. Este criterio se aplica a cualquier pieza.

La foto de panc.vect, procesada con los ajustes guardados, dio seis interiores en E2. E3 da cinco círculos y ningún falso interior. Los diámetros ópticos son 4,292, 4,361, 5,844, 5,864 y 7,584 mm. El programa desconoce las cotas funcionales de los insertos. Se verificó por separado un DXF con los diámetros físicos aportados por el usuario y un STL cerrado de 2,5 mm con sus cinco agujeros.

Superados 36 controles sintéticos de coronas y perfiles, seis escenas de distintos materiales y las nueve variaciones de iluminación y desenfoque. En esas nueve variaciones se conservaron los 39 interiores esperados y quedó un falso positivo. Pasaron las comprobaciones API de silueta, editor, DXF y STL. Validación realizada en Linux. Prueba nativa Windows pendiente.
