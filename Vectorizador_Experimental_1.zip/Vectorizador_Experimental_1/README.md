# Vectorizador V2.6 Experimental 1

Consulta LEEME_PRIMERO.txt para la prueba en paralelo e INFORME.md para la comparación medida frente a V2.6.
