# Informe de Vectorizador V2.6 Experimental 1

Referencia pública de V2.6, commit 810e77b. Ensayos en Linux x64 con Python 3.12.14, OpenCV 4.14.0, Shapely 2.2.0 y Chromium. La instalación Windows del propietario queda pendiente de comparación.

## Del píxel a la geometría

El servidor FastAPI detecta marcadores y excluye la plantilla antes de segmentar. Selecciona un componente y reconstruye sus huecos y bordes. Recupera perforaciones adicionales con varios umbrales. El editor transforma los contornos a coordenadas CAD según la calibración y conserva las ediciones en VECT1. El DXF original usa las entidades nominales. La extrusión y el DXF ajustado comparten corrección X/Y y offset exterior. El STL verifica la triangulación y la vista previa mediante hash.

La apertura morfológica con núcleo par desplazaba la máscara un píxel en ambos ejes. El motor experimental emplea anclajes complementarios para corregir ese desplazamiento. El radio de un círculo ya reconocido se refina con 96 perfiles de intensidad y vuelve al ajuste anterior cuando el soporte óptico es insuficiente. Para un agujero junto al exterior se comprueba la corona oscura antes de admitir un círculo con pared fina. La recuperación de círculos adicionales comprueba los ejes del candidato. Los pequeños contornos interiores ambiguos conservan su geometría y pueden activar el indicador de revisión existente.

Los perfiles cerrados geométricamente idénticos se rechazan antes de calcular sus relaciones de anidamiento. En V2.6 dos perfiles coincidentes podían considerarse mutuamente padres y bloquear el cálculo de profundidad. La prueba experimental devuelve un error gestionado. El lanzador, la identidad de versión y las rutas para el EXE se han separado para pruebas en paralelo.

## Resultados

| Ensayo | V2.6 | Experimental |
|---|---:|---:|
| Error absoluto medio de diámetro, 36 discos | 0,190 mm | 0,025 mm |
| Percentil 95 / máximo de esos errores | 0,383 / 0,631 mm | 0,074 / 0,101 mm |
| Círculos reconocidos en los 36 discos | 36 | 36 |
| Agujeros a 3,34 px/mm sobre réplica sintética del perfil DXF | 4 de 5 | 5 de 5 |
| Ø de punta en esa réplica, nominal 8 mm | omitido | 7,956 mm |
| Desviación de Hausdorff del borde exterior en esa réplica | 0,706 mm | 0,351 mm |
| Falsos interiores con 3 marcas a gris 95 / 145 / 190 | 3 / 3 / 3 | 0 / 3 / 3 |
| Tiempo de vectorización de la plantilla V2.1 sin transformar | 182 ms | 176 ms |
| Pico RSS de todo el proceso tras las cuatro variantes | 315 MiB | 324 MiB |

El banco de discos usa tres diámetros, cuatro escalas y tres fases de muestreo. La réplica del DXF se rasterizó con el contorno del usuario y un orificio nominal de 8 mm en la punta. Esta simulación omite la textura y los insertos. En las cuatro resoluciones produjo cinco agujeros en la experimental. El archivo DXF real contenía Ø6,961 mm y cuatro Ø4,700 mm después de la edición. El JPG original no estaba disponible para ejecutar la cadena óptica. Las cotas X/Y y los centros carecen de medidas físicas independientes. La desviación de Hausdorff evalúa el borde de la máscara frente al perfil sintético en su posición conocida.

En los dos ensayos de marcas más brillantes quedan tres falsos interiores. Los tres se señalan para revisión. El criterio también puede señalar ranuras reales pequeñas. En las imágenes de plantilla con perspectiva quedó un interior representado como polilínea en ambas versiones. La calibración detectó las cuatro variantes de la plantilla. Los tiempos proceden de la mediana de tres llamadas tras un calentamiento por imagen en una máquina compartida. El RSS incluye Python, los lectores importados, el cliente de prueba y las imágenes retenidas.

## Exportación, editor y conservación

Se abrieron los 24 DXF históricos con ezdxf. Sus auditorías devolvieron cero errores. Se exportaron los dos ejemplos PNG en DXF y STL de 2,5 mm. Además, se probaron 12 combinaciones en cada versión con ranura, perfil cóncavo, isla, varias regiones y las entidades del DXF real. Los casos incluyen espesor de 1, 2,5 y 3 mm, escala X independiente y offsets de +0,25 y −0,2 mm. Se reabrieron los STL con Trimesh, verificando cierre, orientación, volumen positivo, caras no degeneradas, característica de Euler y espesor. El DXF ajustado se reabrió con ezdxf y GDAL/OGR. Se comprobaron unidades, número de entidades y dimensiones exteriores. La comprobación de extents con OGR admite 0,1 mm por la discretización del lector. Estas pruebas no constituyen detección exhaustiva de autointersecciones tridimensionales.

En Chromium se importó la plantilla en la V2.6 de referencia, se vectorizó, se abrió el editor, se movió un círculo diez veces, se deshizo y rehizo y se guardó el proyecto. La experimental abrió y guardó ese VECT1 conservando foto, geometría, escala, ajustes de extrusión y pilas de edición. COMPROBAR_V2_6.py pasó para las respectivas identidades. Quedan pendientes los proyectos históricos privados, una prueba física del espesor y el ejecutable Windows nativo.

## Recursos y pruebas reproducibles

La aplicación sigue usando OpenCV para los bordes. Pillow 12.3.0 estaba disponible en el entorno de prueba. El README de VectorCraft documenta Windows, MCP y la licencia MIT o Apache-2.0. Su instalación en el equipo del propietario y su aportación a la precisión siguen sin verificarse. Ninguno se ha añadido como dependencia del motor.

Los scripts y registros están en Ensayos. En el entorno de desarrollo instala las dependencias de requirements.txt más httpx, trimesh, scipy y playwright. Los ensayos con navegador usan Chromium en /usr/bin/chromium. El ensayo de CAD usa ogr2ogr. Para cada versión ejecuta ensayo_circulos.py RUTA_APP resultados.json, ensayo_textura.py RUTA_APP, control_salida.py RUTA_APP y ensayo_plantilla.py RUTA_APP. Para ensayo_perfil.py añade la ruta al DXF del usuario, y para ensayo_cad.py es opcional. ensayo_proyecto.py recibe primero la carpeta de V2.6 y después la experimental. Los scripts se ejecutan con Python. El archivo DXF privado se conserva fuera del paquete.

La instalación de Windows, las pruebas con fotografías privadas y la aprobación corresponden a la siguiente validación. El repositorio remoto se consultó en lectura. La entrega se preparó en un checkout local independiente, sin commits ni publicaciones.
