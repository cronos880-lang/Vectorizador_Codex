"""Prueba en Chromium las cuatro vistas de una misma escena de control."""
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

import cv2
from playwright.sync_api import sync_playwright
from ensayo_rutas_e2 import crear_escena


def main():
    app=Path(sys.argv[1]).resolve()
    with tempfile.TemporaryDirectory() as tmp, sync_playwright() as pw:
        root=Path(tmp)
        base=root/'app'
        shutil.copytree(app,base,ignore=shutil.ignore_patterns('.git','__pycache__','Archivos'))
        photo=crear_escena()[:,245:].copy()
        path=root/'placa.png';cv2.imwrite(str(path),photo)
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0))
            port=sock.getsockname()[1]
        proc=subprocess.Popen([sys.executable,'-m','uvicorn','servidor:app','--port',str(port)],
                              cwd=base,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:
            url=f'http://127.0.0.1:{port}'
            for k in range(100):
                try:
                    urllib.request.urlopen(url,timeout=.3).close()
                    break
                except OSError:time.sleep(.1)
            browser=pw.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox'])
            page=browser.new_page()
            page.goto(url)
            page.locator('#fileInput').set_input_files(path)
            page.wait_for_function('state.img?.naturalWidth>0')
            page.locator('#convertBtn').click()
            page.wait_for_function('state.vector && state.binary?.complete && !state.busy')
            page.evaluate("""() => { if(!$('showBinary').checked)$('showBinary').click(); }""")
            assert page.evaluate("""() => {
                const el=document.createElement('canvas');el.width=state.binary.width;el.height=state.binary.height;
                const ctx=el.getContext('2d');ctx.drawImage(state.binary,0,0);
                const px=(x,y)=>ctx.getImageData(x,y,1,1).data[0];
                return px(55+48,95)===255 && px(55+68,170)===255 && px(55+113,116)===0 && px(55+80,97)===0;
            }"""), 'La silueta precisa un taladro y una ranura claros y superficie negra en las marcas.'
            page.evaluate("""() => { $('showBinary').click(); if(!$('showOverlay').checked)$('showOverlay').click(); }""")
            assert page.evaluate("state.vector.contornos.length===3 && $('showOverlay').checked")
            page.locator('#cadToggle').click()
            page.wait_for_function('cad.active && !state.busy')
            page.evaluate("""() => { if(!$('cadPhotoVisible').checked)$('cadPhotoVisible').click(); }""")
            page.wait_for_function('cad.bg.visible && cad.bg.image?.naturalWidth>0')
            assert page.evaluate("cad.entities.length===3 && cad.entities.filter(e=>e.capa==='AGUJEROS').length===2")
            print('Chromium: foto, silueta, contornos sobre foto y editor con fondo. Se conservan taladro y ranura. Las dos marcas están ausentes de silueta y CAD.')
            browser.close()
        finally:
            proc.terminate();proc.wait()


if __name__=='__main__':main()
