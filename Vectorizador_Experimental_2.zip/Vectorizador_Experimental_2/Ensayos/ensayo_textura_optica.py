"""Ensayo del filtrado para dos materiales, tres escalas y detalles sombreados."""
from pathlib import Path
import sys

import cv2
import numpy as np

sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
from motor.agujeros_adicionales import recuperar_agujeros
from motor.textura_optica import filtrar_textura
from motor.vectorizar import extraer_contornos

def contiene(vector, centro):
    for contorno in vector['contornos']:
        if contorno['tipo'] != 'interior':
            continue
        puntos = np.asarray(contorno.get('borde_px') or contorno['puntos'], np.float32)
        if cv2.pointPolygonTest(puntos, centro, False) >= 0:
            return True
    return False


def probar(factor, rotacion, tejido):
    h, w = 336, 485
    fy, fx = np.mgrid[:h,:w]
    papel = 214 + (fx / w)*15
    material = 54 + (12*np.sin(fx*1.3) + 7*np.cos(fy*.73) if tejido else 0)
    imagen = papel.copy()
    imagen[26:246,28:393] = np.broadcast_to(material,imagen.shape)[26:246,28:393]
    imagen = imagen.astype(np.uint8)
    def poligono(centro, forma, valor):
        cv2.fillPoly(imagen,[np.int32(forma)+np.int32(centro)],valor)
    reales = [(75,67),(72,164),(130,180),(232,180),(326,165)]
    cv2.circle(imagen,reales[0],10,170,-1)
    cv2.rectangle(imagen,(60,151),(84,177),165,-1)
    cv2.rectangle(imagen,(119,172),(142,188),158,-1)
    for x in (119,142):
        cv2.circle(imagen,(x,180),8,158,-1)
    poligono(reales[3],[[-6,-5],[5,-5],[5,-1],[0,-1],[0,6],[-6,6]],225)
    # Agujero circular con penumbra parcial cuyo extremo oscuro linda con el material.
    yy,xx = reales[4][1],reales[4][0]
    disco=(fy-yy)**2+(fx-xx)**2<=11**2
    imagen[disco]=np.clip(140+(fx[disco]-xx+11)*3,0,230)
    marcas=[(155,62),(230,80),(315,61)]
    for i,c in enumerate(marcas):
        poligono(c, [[-5,0],[5,-3],[3,5],[-4,6]],155+(i%2)*7)
    mat=cv2.getRotationMatrix2D((w/2,h/2),rotacion,1)
    imagen=cv2.warpAffine(imagen,mat,(w,h),borderValue=218)
    imagen=cv2.resize(imagen,None,fx=factor,fy=factor)
    bgr=cv2.cvtColor(imagen,cv2.COLOR_GRAY2BGR)
    vec=recuperar_agujeros(bgr,extraer_contornos(bgr))
    filtrado=filtrar_textura(bgr,vec)
    def transform(p):
        x,y=(mat@[*p,1])*factor
        return float(x),float(y)
    antes=[contiene(vec,transform(p)) for p in reales]
    despues=[contiene(filtrado,transform(p)) for p in reales]
    assert despues == antes, (factor,rotacion,tejido,'detalle real eliminado',antes,despues)
    trazas=filtrado.get('contornos_textura_descartados',[])
    recuento=sum(contiene(vec,transform(p)) for p in marcas)
    final=sum(contiene(filtrado,transform(p)) for p in marcas)
    assert all('contorno' in entrada and entrada['diferencia_hoja']>0 for entrada in trazas)
    return len(reales), sum(antes), recuento,final


if __name__ == '__main__':
    total=np.zeros(4,dtype=int)
    for factor in (.8,1,1.6):
        for giro in (-4.,0.,6.):
            for tejido in (True,False):
                resultado=probar(factor,giro,tejido)
                total+=np.asarray(resultado)
                print(factor,giro,tejido,resultado)
    print('Detalles dibujados, detectados antes y conservados, marcas previas y finales',total)
    assert total[0] == total[1] == 90, 'Algún detalle real se perdió antes del filtro'
    assert total[2] > 0 and total[3] <= 1, 'Regresión en supresión de marcas'
