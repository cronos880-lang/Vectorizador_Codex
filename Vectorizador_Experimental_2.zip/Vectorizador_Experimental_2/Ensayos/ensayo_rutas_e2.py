"""Comprueba la coherencia API, silueta, editor, DXF y STL con imágenes sintéticas."""
import argparse
import base64
import io
import json
import sys
from pathlib import Path

import cv2
import ezdxf
import numpy as np
import trimesh
from fastapi.testclient import TestClient


def crear_escena():
    img = np.full((340, 540, 3), 218, np.uint8)
    for x in (55, 300):
        cv2.rectangle(img, (x, 50), (x+172, 220), (41, 38, 39), -1)
        cv2.circle(img, (x+48, 95), 12, (218,)*3, -1)
        cv2.rectangle(img, (x+60, 165), (x+95, 177), (218,)*3, -1)
        cv2.circle(img, (x+60, 171), 6, (218,)*3, -1)
        cv2.circle(img, (x+95, 171), 6, (218,)*3, -1)
        p = np.array([(x+108, 110), (x+119, 114), (x+120, 119), (x+110, 119)])
        cv2.fillPoly(img, [p], (153, 149, 154))
        if x == 300:
            cv2.fillPoly(img, [p + [-34, -18]], (156, 154, 150))
    return img


def silueta_desde_vector(vector):
    img = np.full((vector['alto_imagen'], vector['ancho_imagen']), 255, np.uint8)
    for cont in sorted(vector['contornos'], key=lambda c: c['tipo']=='interior'):
        color = 255 if cont['tipo']=='interior' else 0
        if cont.get('circulo'):
            circle = cont['circulo']
            cv2.circle(img, tuple(np.rint(circle['centro_px']).astype(int)),
                       max(1, round(circle['radio_px'])), color, -1)
        else:
            cv2.fillPoly(img,[np.rint(cont['puntos']).astype(np.int32)],color)
    return img


def leer_dxf(response):
    response.raise_for_status()
    doc = ezdxf.read(io.StringIO(response.text))
    assert doc.units==4 and not doc.audit().errors
    return [e.dxftype() for e in doc.modelspace()]


def probar_vector(cliente,img,recorte,recuperar):
    png = cv2.imencode('.png',img)[1].tobytes()
    files = {'archivo':('foto.png',png,'image/png')}
    data = {'recuperar':str(recuperar).lower()}
    if recorte:
        data['recorte']=json.dumps(recorte)
    resp = cliente.post('/api/vectorizar',files=files,data=data)
    resp.raise_for_status()
    v=resp.json()
    mask = cv2.imdecode(np.frombuffer(base64.b64decode(v['silueta_png'].split(',')[-1]),np.uint8),0)
    assert np.array_equal(mask,silueta_desde_vector(v)), 'La silueta discrepa de los contornos.'
    p=dict(vector=v,px_mm_x=4.,px_mm_y=4.,guardar_copia=False)
    fa=cliente.post('/api/editor/fondo',files=files,data={'datos':json.dumps(p)})
    fa.raise_for_status()
    b=cliente.post('/api/editor/iniciar',json=p);assert b.is_success,b.text
    ent=b.json()['entidades']
    med=cliente.post('/api/medidas',json=p);med.raise_for_status()
    assert med.json()==b.json()['resumen']
    assert len(ent)==len(v['contornos'])
    orig=leer_dxf(cliente.post('/api/exportar',json=p))
    edit=leer_dxf(cliente.post('/api/exportar',json=dict(p,entidades_editadas=ent)))
    assert orig==edit and len(orig)==len(ent)
    s=cliente.post('/api/exportar-stl',json=dict(p,grosor=2.5));s.raise_for_status()
    m=trimesh.load(io.BytesIO(s.content),file_type='stl')
    assert m.is_volume and m.extents[2]==2.5 and m.euler_number==2*(2-len(ent))
    q=dict(p,grosor=2.5,sha256_stl_esperado=s.headers['X-Vectorizador-STL-SHA256'])
    adj=leer_dxf(cliente.post('/api/exportar-dxf-ajustado',json=q))
    assert len(adj)==len(orig)
    return {'recorte':recorte,'recuperar':recuperar,'interiores':len(ent)-1,'tipos_DXF':orig}


def main():
    cli=argparse.ArgumentParser()
    cli.add_argument('aplicacion',type=Path)
    cli.add_argument('imagenes',nargs='*',type=Path)
    args=cli.parse_args()
    sys.path.insert(0,str(args.aplicacion.resolve()))
    from servidor import app
    c=TestClient(app)
    imagen=crear_escena()
    respuesta=c.post('/api/piezas/detectar',files={'archivo':('doble.png',cv2.imencode('.png',imagen)[1].tobytes(),'image/png')})
    respuesta.raise_for_status()
    recortes=[p['recorte'] for p in respuesta.json()['piezas']]
    assert len(recortes)==2
    # Documento de un proyecto anterior cuyo contorno ajustado tenía dos
    # vértices con bulge y que en E1 impedía iniciar el editor.
    from motor.vectorizar import extraer_contornos
    heredado = extraer_contornos(imagen, recorte=recortes[0])
    prueba = c.post('/api/editor/iniciar', json=dict(vector=heredado, px_mm_x=4, px_mm_y=4))
    print('Proyecto previo con contorno ambiguo:', prueba.status_code, flush=True)
    if (args.aplicacion/'motor'/'procesamiento_foto.py').is_file():
        prueba.raise_for_status()
        heredadas = prueba.json()['entidades']
        assert len(heredadas) == len(heredado['contornos'])
        assert all(len(e['vertices']) >= 3 for e in heredadas if e['tipo']=='polyline')
    for recorte in [None]+recortes:
        for recuperar in (True,False):
            print(json.dumps(probar_vector(c,imagen,recorte,recuperar)))
    for ruta in args.imagenes:
        photo=cv2.imread(str(ruta))
        print(ruta.name,probar_vector(c,photo,None,True))


if __name__=='__main__':main()
