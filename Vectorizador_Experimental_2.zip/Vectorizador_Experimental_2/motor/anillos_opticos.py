"""Reconstrucción conservadora de interiores fragmentados con corona óptica.

La curva elegida sigue el borde exterior visible de la corona representada por
los fragmentos. Este ajuste reconoce una geometría óptica, no un diámetro
funcional oculto por un inserto.
"""
from __future__ import annotations

import cv2
import numpy as np


_ANGULOS = np.arange(64) * (2 * np.pi / 64)
_DIRECCIONES = np.column_stack((np.cos(_ANGULOS), np.sin(_ANGULOS)))


def _semillas(gris, puntos):
    """Propone centros a partir del fragmento y de sus componentes a varios niveles."""
    (cx, cy), radio = cv2.minEnclosingCircle(puntos)
    propuestas = [(cx, cy, radio)]
    margen = int(np.ceil(radio * 2.8 + 3))
    x = max(0, int(cx) - margen)
    y = max(0, int(cy) - margen)
    sub = gris[y:int(cy) + margen + 1, x:int(cx) + margen + 1]
    base, brillo = np.percentile(sub, (20, 98))
    if brillo - base < 24:
        return propuestas
    for nivel in base + (brillo-base) * np.array([.28, .48, .68]):
        mascara = np.uint8(sub > nivel)
        curvas, _ = cv2.findContours(mascara, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for curva in curvas:
            if len(curva) < 5:
                continue
            (u, v), r = cv2.minEnclosingCircle(curva)
            u += x
            v += y
            if .65*radio <= r <= 2.0*radio and np.hypot(u-cx, v-cy) < radio:
                propuestas.append((u, v, r))
    # Las curvas coincidentes a varios umbrales aportan la misma hipótesis.
    unicas = {}
    for u, v, r in propuestas:
        unicas.setdefault((round(u), round(v), round(r)), (u, v, r))
    return list(unicas.values())


def _perfiles(gris, centro, radios):
    xy = centro + radios[:, None, None] * _DIRECCIONES
    return cv2.remap(gris, xy[:, :, 0].astype(np.float32), xy[:, :, 1].astype(np.float32),
                     cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE).astype(float)


def _ajustar_corona(gris, semilla):
    centro = np.array(semilla[:2])
    radio = semilla[2]
    if radio < 4.2:
        return None
    # Localizar el borde de salida de la corona en cada dirección. Una sola
    # recta brillante o dos arcos laterales no soportan el ajuste completo.
    tolerancia = max(2.0, .19*radio)
    radios = np.linspace(radio-tolerancia, radio+tolerancia, 17)
    paso = np.clip(.12*radio, .85, 2.)
    grad = _perfiles(gris, centro, radios-paso) - _perfiles(gris, centro, radios+paso)
    idx = grad.argmax(axis=0)
    soporte = grad[idx, np.arange(len(_ANGULOS))] >= 17
    if soporte.mean() < .72:
        return None
    puntos = (radios[idx, None] * _DIRECCIONES)[soporte]
    A = np.column_stack((2*puntos, np.ones(len(puntos))))
    sol, _, _, _ = np.linalg.lstsq(A, np.square(puntos).sum(axis=1), rcond=None)
    radio_optico = np.sqrt(max(0., sol[2]+sol[:2] @ sol[:2]))
    if abs(radio_optico-radio) > tolerancia or np.linalg.norm(sol[:2]) > tolerancia:
        return None
    centro = centro + sol[:2]
    radio = radio_optico
    # Un contorno angular alrededor de un centro claro se conserva como tal.
    # La corona ha de ser más clara que el núcleo y que la pared exterior.
    ancho = float(np.clip(.13*radio, .95, 2.5))
    barrido = np.array([.14*radio, .30*radio, .55*radio, .70*radio,
                        .82*radio, radio-ancho, radio+ancho])
    p = _perfiles(gris, centro, barrido)
    nucleo = np.median(p[:2], axis=0)
    corona = np.max(p[2:6], axis=0)
    salto = p[-2] - p[-1]
    # Un corte verdadero en la corona sigue siendo una abertura. Incluso en
    # los sectores sombreados exigimos algún soporte de borde, más débil que
    # el necesario para estimar el círculo.
    sin_borde = (salto < 7) & (corona-p[-1] < 12)
    hueco_angular = sin_borde & np.roll(sin_borde, 1) & np.roll(sin_borde, 2)
    if np.any(hueco_angular):
        return None
    borde = salto > 16
    anular = (corona-nucleo > 18) & borde
    if (anular.mean() < .65 or borde.mean() < .78 or
            np.min(borde.reshape(4, -1).mean(axis=1)) < .50):
        return None
    error = np.abs(np.linalg.norm(puntos-sol[:2], axis=1)-radio)
    if np.percentile(error, 80) > max(1.1, .075*radio):
        return None
    puntuacion = float(anular.mean() + borde.mean() - np.median(error)/radio)
    return puntuacion, centro, radio


def reconstruir_anillos(imagen, vector):
    """Reemplaza fragmentos de una misma corona sólo cuando su borde la sustenta."""
    contornos = vector.get('contornos', [])
    candidatos = [i for i, c in enumerate(contornos)
                  if c['tipo'] == 'interior' and not c.get('circulo')]
    if not candidatos:
        return {**vector, 'anillos_reconstruidos': 0}
    gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
    bordes = [np.asarray(c.get('borde_px') or c['puntos'], np.float32).reshape(-1, 2)
              for c in contornos]
    cajas = [cv2.boundingRect(p) for p in bordes]
    exteriores = [p for p, c in zip(bordes, contornos) if c['tipo'] == 'exterior']
    sustituciones = {}
    omitidos = set()
    registros = []
    for i in sorted(candidatos, key=lambda k: contornos[k].get('area_px2', 0), reverse=True):
        if i in omitidos:
            continue
        _, _, w, h = cajas[i]
        if min(w, h) < 4 or max(w, h) > 320 or max(w, h) > 3.2 * min(w, h):
            continue
        mejor = None
        for semilla in _semillas(gris, bordes[i]):
            ajuste = _ajustar_corona(gris, semilla)
            if ajuste and (mejor is None or ajuste[0] > mejor[0]):
                mejor = ajuste
        if mejor is None:
            continue
        _, centro, radio = mejor
        cx, cy = map(float, centro)
        if not any(cv2.pointPolygonTest(ext, (cx, cy), True) > radio+.6 for ext in exteriores):
            continue
        grupo = []
        tolerancia = max(2., .14*radio)
        for j, c in enumerate(contornos):
            if c['tipo'] != 'interior':
                continue
            x, y, w, h = cajas[j]
            limite = radio + tolerancia
            if x > cx+limite or y > cy+limite or x+w < cx-limite or y+h < cy-limite:
                continue
            d = np.linalg.norm(bordes[j]-centro, axis=1)
            if d.min() > limite:
                # El candidato podría envolver o atravesar este perfil.
                if cv2.pointPolygonTest(bordes[j], (cx, cy), False) >= 0:
                    grupo = []
                    break
                continue
            # Evitar absorber otro mecanizado, un círculo definido o una
            # entidad que cruza el perímetro de la corona.
            previo = c.get('circulo')
            mismo_borde = previo is None or (
                abs(previo['radio_px'] - radio) <= max(.7, .08*radio) and
                np.linalg.norm(np.asarray(previo['centro_px'])-centro) <= max(.75, .08*radio))
            if (d.max() > limite or np.percentile(d, 90) < .73*radio or
                    not mismo_borde or j in omitidos):
                grupo = []
                break
            grupo.append(j)
        if i not in grupo:
            continue
        puntos = (centro+radio*_DIRECCIONES).round(4).tolist()
        sustituciones[i] = {'tipo': 'interior', 'puntos': puntos,
                            'area_px2': round(float(np.pi*radio**2), 2),
                            'origen_deteccion': 'anillo_optico',
                            'circulo': {'centro_px': [cx, cy], 'radio_px': float(radio),
                                        'metodo': 'corona_fotografica'},
                            'revision_recomendada': True,
                            'motivo_revision': 'Comprobar el borde exterior del inserto visible'}
        omitidos.update(grupo)
        registros.append({'centro_px': [cx, cy], 'radio_px': float(radio),
                          'fragmentos_originales': [contornos[j] for j in grupo]})
    salida = [sustituciones.get(i, c) for i, c in enumerate(contornos)
              if i in sustituciones or i not in omitidos]
    return {**vector, 'contornos': salida, 'anillos_reconstruidos': len(registros),
            'ajustes_anillos': registros}
