# Vectorizador V2.6 Experimental 2

## Cambios del motor

El motor comprueba la corona de los insertos sobre la foto, reúne los fragmentos compatibles y estima su centro y radio sobre el borde exterior observado. Un anillo visible puede tener un diámetro exterior distinto del diámetro funcional del taladro. Para pequeñas regiones interiores compara las intensidades con la hoja cercana y con el material de la pieza. Conserva los candidatos ambiguos. El vector almacena los contornos descartados y el motivo o evidencia del cambio, y muestra los recuentos al vectorizar.

La silueta binaria se genera a partir de la lista definitiva de entidades ópticas. Esa lista también alimenta la superposición, el editor y la exportación. Al cargar un proyecto guardado se respeta su edición anterior. Importar de nuevo la foto permite comparar las dos versiones. Se validó asimismo el caso de una polilínea reducida a dos vértices por el ajuste de arcos; el motor recupera la polilínea de origen cuando el ajuste produciría una entidad no admitida por el editor.

## Comparación medida

Imágenes de prueba sintéticas, sin dimensiones ni coordenadas específicas de la pieza del usuario en el motor. El banco compara cada interior con su objetivo por solapamiento y posición, desde el JPEG hasta el DXF reabierto. Incluye tejidos con insertos dorados, una placa con insertos grises y ranura y un disco con un recorte irregular y un taladro sombreado. La segunda serie cambia la exposición, el desenfoque, la orientación, la escala, la semilla y la compresión JPEG. Las mediciones usan la escala conocida de la imagen generada.

| Serie | Versión | Interiores correctos | Falsos interiores | Aros reconocidos como círculos |
|---|---|---:|---:|---:|
| 6 escenas | E1 | 26/26 | 14 | 8/12 |
| 6 escenas | E2 | 26/26 | 0 | 12/12 |
| 9 variaciones | E1 | 39/39 | 21 | 13/18 |
| 9 variaciones | E2 | 39/39 | 1 | 18/18 |

El banco de regresión reabrió proyectos VECT1 en Chromium, verificó la edición, y comprobó DXF y STL, incluida la extrusión de 2,5 mm. Los ensayos se ejecutaron en Linux. La prueba nativa Windows y la repetición con el JPEG original de las capturas quedan pendientes. La evaluación con sombras y materiales sintéticos cubre las situaciones del banco; una marca con el mismo aspecto que una abertura real sigue siendo ambigua en una sola foto.

Los ensayos y registros están en Ensayos/. Para repetir las dos series usa Python con las dependencias del programa, httpx, scipy, trimesh y las herramientas indicadas en los scripts. Ejecuta ensayo_materiales_e2.py y ensayo_variaciones_e2.py pasando primero el directorio de la aplicación y después el nombre de un archivo JSON de resultados.

Las seis escenas sirvieron también para desarrollar el algoritmo. Los nueve casos adicionales evalúan cambios de captura sobre esas mismas familias geométricas. La lámina Ensayos/comparativa_e2.png superpone los DXF de ambas versiones a una misma imagen sintética. La forma de los insertos y las tolerancias que admite la fotografía deben contrastarse con piezas físicas. Los registros individuales conservan resultados por caso.
