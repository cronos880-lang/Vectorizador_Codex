# Vectorizador V2.6 Experimental 2

Las instrucciones de Windows están en LEEME_PRIMERO.txt y los resultados en INFORME.md.
